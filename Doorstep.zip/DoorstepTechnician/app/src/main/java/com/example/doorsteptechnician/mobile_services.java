package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class mobile_services extends AppCompatActivity {
    ImageView mobile_dashboard_img;
    CardView mobile_screen_card,mobile_battery_card,mobile_water_card,mobile_camera_card,mobile_speaker_card,mobile_data_card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_services);

        mobile_dashboard_img= findViewById(R.id.mobile_dashboard_img);
        mobile_screen_card= findViewById(R.id.mobile_screen_card);
        mobile_battery_card= findViewById(R.id.mobile_battery_card);
        mobile_water_card= findViewById(R.id.mobile_water_card);
        mobile_camera_card= findViewById(R.id.mobile_camera_card);
        mobile_speaker_card= findViewById(R.id.mobile_speaker_card);
        mobile_data_card= findViewById(R.id.mobile_data_card);

        // Mobile Screen Repair Intent
        mobile_screen_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mobile_screen= new Intent(mobile_services.this,mobile_technician.class);
                startActivity(mobile_screen);
                Toast.makeText(mobile_services.this, "Clicked on Mobile Screen Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Mobile Battery Replacement Intent
        mobile_battery_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mobile_battery= new Intent(mobile_services.this,mobile_technician.class);
                startActivity(mobile_battery);
                Toast.makeText(mobile_services.this, "Clicked on Mobile Battery Replacement", Toast.LENGTH_SHORT).show();
            }
        });
        // Mobile Water damage repair Intent
        mobile_water_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mobile_water= new Intent(mobile_services.this,mobile_technician.class);
                startActivity(mobile_water);
                Toast.makeText(mobile_services.this, "Clicked on Mobile Water Damage Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Mobile Camera repair Intent
        mobile_camera_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mobile_camera= new Intent(mobile_services.this,mobile_technician.class);
                startActivity(mobile_camera);
                Toast.makeText(mobile_services.this, "Clicked on Mobile Camera repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Mobile Speaker repair Intent
        mobile_speaker_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mobile_speaker= new Intent(mobile_services.this,mobile_technician.class);
                startActivity(mobile_speaker);
                Toast.makeText(mobile_services.this, "Clicked on Mobile Speaker repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Mobile Data Recovery Intent
        mobile_data_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mobile_data= new Intent(mobile_services.this,mobile_technician.class);
                startActivity(mobile_data);
                Toast.makeText(mobile_services.this, "Clicked on Mobile Data Recovery", Toast.LENGTH_SHORT).show();
            }
        });
    }
}