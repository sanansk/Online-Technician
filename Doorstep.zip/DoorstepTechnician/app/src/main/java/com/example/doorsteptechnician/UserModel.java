package com.example.doorsteptechnician;

public class UserModel {
    private String fname, lname,emaill;

    public UserModel() {
    }

    public UserModel(String firstname, String lastname, String email){
        this.fname= firstname;
        this.lname= lastname;
        this.emaill= email;
    }

    public String getFirstname() {
        return fname;
    }

    public void setFirstname(String firstname) {
        this.fname = firstname;
    }

    public String getLastname() {
        return lname;
    }

    public void setLastname(String lastname) {
        this.lname = lastname;
    }

    public String getEmail() {
        return emaill;
    }

    public void setEmail(String email) {
        this.emaill = email;
    }
}
