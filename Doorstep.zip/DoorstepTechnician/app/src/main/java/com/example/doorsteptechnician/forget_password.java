package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class forget_password extends AppCompatActivity {

    ImageView forgot_login_image;
    TextView forgot_txt;
    EditText forgotemail;
    Button getpassword;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        forgot_login_image= findViewById(R.id.forgot_login_image);
        forgot_txt= findViewById(R.id.forgot_txt);
        forgotemail= findViewById(R.id.forgotemail);
        getpassword = findViewById(R.id.getpassword);

    }
}