package com.example.doorsteptechnician;


import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;


public class ac_services extends AppCompatActivity {

    ImageView ac_dashboard_img;
    CardView ac_install_card, ac_repair_card, ac_maintenance_card, ac_tune_card, ac_duct_card, ac_replace_card;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ac_services);

        ac_dashboard_img = findViewById(R.id.ac_dashboard_img);
        ac_install_card = findViewById(R.id.ac_install_card);
        ac_repair_card = findViewById(R.id.ac_repair_card);
        ac_maintenance_card = findViewById(R.id.ac_maintenance_card);
        ac_tune_card = findViewById(R.id.ac_tune_card);
        ac_duct_card = findViewById(R.id.ac_duct_card);
        ac_replace_card = findViewById(R.id.ac_replace_card);

        //Ac Installation intent
        ac_install_card.setOnClickListener(view -> {
            Intent ac_install = new Intent(ac_services.this, ac_technician.class);
            startActivity(ac_install);
            Toast.makeText(ac_services.this, "Clicked on AC Installation", Toast.LENGTH_SHORT).show();
        });
    /*            FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();
                Fragment ac_tech_fragment= new ac_technician_Fragment();
                fragmentTransaction.replace(R.id.ac_frame_layout,ac_tech_fragment);
                fragmentTransaction.commit();
                */

        //Ac Repair intent
        ac_repair_card.setOnClickListener(view -> {
            Intent ac_repair = new Intent(ac_services.this, ac_technician.class);
            startActivity(ac_repair);
            Toast.makeText(ac_services.this, "Clicked on AC Repair", Toast.LENGTH_SHORT).show();
        });
        //Ac Maintenance intent
        ac_maintenance_card.setOnClickListener(view -> {
            Intent ac_maintain = new Intent(ac_services.this, ac_technician.class);
            startActivity(ac_maintain);
            Toast.makeText(ac_services.this, "Clicked on AC Maintenance", Toast.LENGTH_SHORT).show();
        });
        //Ac Tune-up intent
        ac_tune_card.setOnClickListener(view -> {
            Intent ac_tune = new Intent(ac_services.this, ac_technician.class);
            startActivity(ac_tune);
            Toast.makeText(ac_services.this, "Clicked on AC Tune-up", Toast.LENGTH_SHORT).show();
        });
        //Ac Duct Cleaning intent
        ac_duct_card.setOnClickListener(view -> {
            Intent ac_duct = new Intent(ac_services.this, ac_technician.class);
            startActivity(ac_duct);
            Toast.makeText(ac_services.this, "Clicked on AC Duct Cleaning", Toast.LENGTH_SHORT).show();
        });
        //Ac Replace intent
        ac_replace_card.setOnClickListener(view -> {
            Intent ac_replace = new Intent(ac_services.this, ac_technician.class);
            startActivity(ac_replace);
            Toast.makeText(ac_services.this, "Clicked on AC Replacement", Toast.LENGTH_SHORT).show();
        });
    }
}