package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class computer_services extends AppCompatActivity {
    ImageView comp_dashboard_img;
    CardView comp_os_card,comp_motherboard_card,comp_hard_ram_card,comp_tune_up_card,comp_fan_card,comp_firewall_card;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer_services);

        comp_dashboard_img= findViewById(R.id.comp_dashboard_img);
        comp_os_card= findViewById(R.id.comp_os_card);
        comp_motherboard_card= findViewById(R.id.comp_motherboard_card);
        comp_hard_ram_card= findViewById(R.id.comp_hard_ram_card);
        comp_tune_up_card= findViewById(R.id.comp_tune_up_card);
        comp_fan_card= findViewById(R.id.comp_fan_card);
        comp_firewall_card= findViewById(R.id.comp_firewall_card);

        //Computer OS installation Intent
        comp_os_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent comp_os= new Intent(computer_services.this, computer_technician.class);
                startActivity(comp_os);
                Toast.makeText(computer_services.this, "Clicked on Computer OS Installation", Toast.LENGTH_SHORT).show();
            }
        });
        //Computer Motherboard Repair Intent
        comp_motherboard_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent comp_motherboard= new Intent(computer_services.this, computer_technician.class);
                startActivity(comp_motherboard);
                Toast.makeText(computer_services.this, "Clicked on Computer Motherboard Repair", Toast.LENGTH_SHORT).show();
            }
        });
        //Computer Hard-ram Intent
        comp_hard_ram_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent comp_hard= new Intent(computer_services.this, computer_technician.class);
                startActivity(comp_hard);
                Toast.makeText(computer_services.this, "Clicked on Computer Hard-ram Upgrade", Toast.LENGTH_SHORT).show();
            }
        });
        //Computer Tune-up Intent
        comp_tune_up_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent comp_tune= new Intent(computer_services.this, computer_technician.class);
                startActivity(comp_tune);
                Toast.makeText(computer_services.this, "Clicked on Computer Tune-up", Toast.LENGTH_SHORT).show();
            }
        });
        //Computer Fan Replacement Intent
        comp_fan_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent comp_fan= new Intent(computer_services.this, computer_technician.class);
                startActivity(comp_fan);
                Toast.makeText(computer_services.this, "Clicked on Computer Fan Replacement", Toast.LENGTH_SHORT).show();
            }
        });
        //Computer Firewall setup Intent
        comp_firewall_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent comp_firewall= new Intent(computer_services.this, computer_technician.class);
                startActivity(comp_firewall);
                Toast.makeText(computer_services.this, "Clicked on Computer firewall Setup", Toast.LENGTH_SHORT).show();
            }
        });
    }
}