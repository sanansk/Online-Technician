package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class laptop_services extends AppCompatActivity {
    ImageView laptop_dashboard_img;
    CardView laptop_screen_card,laptop_motherboard_card,laptop_hard_ram_card,laptop_power_jack_card,laptop_fan_card,laptop_cyber_card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laptop_services);

        laptop_dashboard_img= findViewById(R.id.laptop_dashboard_img);
        laptop_screen_card=findViewById(R.id.laptop_screen_card);
        laptop_motherboard_card= findViewById(R.id.laptop_motherboard_card);
        laptop_hard_ram_card= findViewById(R.id.laptop_hard_ram_card);
        laptop_power_jack_card= findViewById(R.id.laptop_power_jack_card);
        laptop_fan_card= findViewById(R.id.laptop_fan_card);
        laptop_cyber_card= findViewById(R.id.laptop_cyber_card);

        // Laptop Screen Repair intent
        laptop_screen_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lap_screen= new Intent(laptop_services.this,laptop_technician.class);
                startActivity(lap_screen);
                Toast.makeText(laptop_services.this, "Clicked  on Laptop Screen Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Laptop Motherboard Repair intent
        laptop_motherboard_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lap_motherboard= new Intent(laptop_services.this,laptop_technician.class);
                startActivity(lap_motherboard);
                Toast.makeText(laptop_services.this, "Clicked  on Laptop Motherboard Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Laptop Hard-ram Repair intent
        laptop_hard_ram_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lap_hard_ram= new Intent(laptop_services.this,laptop_technician.class);
                startActivity(lap_hard_ram);
                Toast.makeText(laptop_services.this, "Clicked  on Laptop Hard-ram Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Laptop Power-jack Repair intent
        laptop_power_jack_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lap_power_jack= new Intent(laptop_services.this,laptop_technician.class);
                startActivity(lap_power_jack);
                Toast.makeText(laptop_services.this, "Clicked  on Laptop Power_jack Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Laptop Fan Repair intent
        laptop_fan_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lap_fan= new Intent(laptop_services.this,laptop_technician.class);
                startActivity(lap_fan);
                Toast.makeText(laptop_services.this, "Clicked  on Laptop Fan Repair", Toast.LENGTH_SHORT).show();
            }
        });
        // Laptop Cyber Security intent
        laptop_cyber_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lap_cyber= new Intent(laptop_services.this,laptop_technician.class);
                startActivity(lap_cyber);
                Toast.makeText(laptop_services.this, "Clicked  on Laptop Cyber Security", Toast.LENGTH_SHORT).show();
            }
        });
    }
}