package com.example.doorsteptechnician;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {
    TextView wlcmlogintxt;
 TextView wlcmtxt1;
 ImageView wlcmimage;
 TextView wlcmtxt3;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);

        wlcmtxt1= findViewById(R.id.wlcmtxt1);
        wlcmimage= findViewById(R.id.wlcmimage);
        wlcmtxt3= findViewById(R.id.wlcmtxt3);

        Button getstartbtn = findViewById(R.id.getstartbtn);
        wlcmlogintxt= findViewById(R.id.wlcmlogintxt);
        getstartbtn.setOnClickListener(view -> openSignup());
        wlcmlogintxt.setOnClickListener(view -> {
            Intent intent= new Intent(Welcome.this,Login.class);
            startActivity(intent);

            Toast.makeText(Welcome.this, "Clicked on Log in", Toast.LENGTH_LONG).show();
        });
    }

    public void openSignup(){
        Intent intent = new Intent(this, Signup.class);
        startActivity(intent);

        Toast.makeText(Welcome.this, "Clicked on Get Started", Toast.LENGTH_LONG).show();

    }
    }