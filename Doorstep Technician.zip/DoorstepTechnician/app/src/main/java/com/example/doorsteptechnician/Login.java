package com.example.doorsteptechnician;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
TextView logintxt2, logintxt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        logintxt1= findViewById(R.id.logintxt1);
        logintxt2= findViewById(R.id.logintxt2);
        logintxt2.setOnClickListener(view -> {
            Intent intent= new Intent(Login.this,Signup.class);
            startActivity(intent);

            Toast.makeText(Login.this, "Clicked on Sign up", Toast.LENGTH_LONG).show();
        });
    }
}