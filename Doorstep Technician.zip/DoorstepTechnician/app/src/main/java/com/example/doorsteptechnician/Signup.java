package com.example.doorsteptechnician;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Signup extends AppCompatActivity {
    TextView signuptxt2, signuptxt1;
    ImageView signup_image;

    EditText firstname, lastname, email, password, confpswrd;
    Button signupbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        firstname = findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confpswrd = findViewById(R.id.confpswrd);

        signup_image = findViewById(R.id.signup_image);
        signuptxt1 = findViewById(R.id.signuptxt1);
        signupbtn = findViewById(R.id.signupbtn);
        signuptxt2 = findViewById(R.id.signuptxt2);

        signupbtn.setOnClickListener(view -> {

            Intent intent = new Intent(Signup.this, Home.class);
            startActivity(intent);

            Toast.makeText(Signup.this, "Clicked on Signup", Toast.LENGTH_LONG).show();
        });
        signuptxt2.setOnClickListener(view -> {
            Intent intent = new Intent(Signup.this, Login.class);
            startActivity(intent);

            Toast.makeText(Signup.this, "Clicked on Log in", Toast.LENGTH_LONG).show();
        });
    }

}