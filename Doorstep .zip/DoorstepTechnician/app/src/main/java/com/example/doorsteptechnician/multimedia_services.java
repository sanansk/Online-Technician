package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class multimedia_services extends AppCompatActivity {
    ImageView multimedia_dashboard_img;
    CardView multi_screen_card,multi_driverboard_card,multi_colorwheel_card,multi_pixels_card,multi_dlp_chip_card,multi_power_card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multimedia_services);

        multimedia_dashboard_img= findViewById(R.id.multimedia_dashboard_img);
        multi_screen_card= findViewById(R.id.multi_screen_card);
        multi_driverboard_card= findViewById(R.id.multi_driverboard_card);
        multi_colorwheel_card= findViewById(R.id.multi_colorwheel_card);
        multi_pixels_card= findViewById(R.id.multi_pixels_card);
        multi_dlp_chip_card= findViewById(R.id.multi_dlp_chip_card);
        multi_power_card= findViewById(R.id.multi_power_card);

        // Multimedia Screen Repair Intent
        multi_screen_card.setOnClickListener(view -> {
            Intent multi_screen= new Intent(multimedia_services.this, multimedia_technician.class);
            startActivity(multi_screen);
            Toast.makeText(multimedia_services.this, "Clicked on Multimedia Screen Repair", Toast.LENGTH_SHORT).show();
        });
        // Multimedia Driverboard Repair Intent
        multi_driverboard_card.setOnClickListener(view -> {
            Intent multi_driverboard= new Intent(multimedia_services.this, multimedia_technician.class);
            startActivity(multi_driverboard);
            Toast.makeText(multimedia_services.this, "Clicked on Multimedia Driverboard Repair", Toast.LENGTH_SHORT).show();
        });
        // Multimedia Color Wheel Repair Intent
        multi_colorwheel_card.setOnClickListener(view -> {
            Intent multi_colorwheel= new Intent(multimedia_services.this, multimedia_technician.class);
            startActivity(multi_colorwheel);
            Toast.makeText(multimedia_services.this, "Clicked on Multimedia Color Wheel Repair", Toast.LENGTH_SHORT).show();
        });
        // Multimedia Dead Pixel Repair Intent
        multi_pixels_card.setOnClickListener(view -> {
            Intent multi_pixel= new Intent(multimedia_services.this, multimedia_technician.class);
            startActivity(multi_pixel);
            Toast.makeText(multimedia_services.this, "Clicked on Multimedia Dead Pixel Repair", Toast.LENGTH_SHORT).show();
        });
        // Multimedia Dlp_chip Repair Intent
        multi_dlp_chip_card.setOnClickListener(view -> {
            Intent multi_dlp_chip= new Intent(multimedia_services.this, multimedia_technician.class);
            startActivity(multi_dlp_chip);
            Toast.makeText(multimedia_services.this, "Clicked on Multimedia Dlp_chip Repair", Toast.LENGTH_SHORT).show();
        });
        // Multimedia Power Supply Repair Repair Intent
        multi_power_card.setOnClickListener(view -> {
            Intent multi_power= new Intent(multimedia_services.this, multimedia_technician.class);
            startActivity(multi_power);
            Toast.makeText(multimedia_services.this, "Clicked on Multimedia Power Supply Repair", Toast.LENGTH_SHORT).show();
        });
    }
}