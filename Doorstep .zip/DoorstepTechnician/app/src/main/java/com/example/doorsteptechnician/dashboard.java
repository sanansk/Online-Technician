package com.example.doorsteptechnician;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;


public class dashboard extends AppCompatActivity {

    Toolbar toolbar;
    DrawerLayout drawerLayout;
    NavigationView navigationView1;
    CardView ac_card, laptop_card, mobile_card, multimedia_card, plumbing_card, fridge_card, computer_card, wm_card;

    @SuppressLint({"MissingInflatedId", "NonConstantResourceId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        drawerLayout = findViewById(R.id.drawer_layout);
       /*
       ac_card = findViewById(R.id.ac_card);
        laptop_card = findViewById(R.id.laptop_card);
        mobile_card = findViewById(R.id.mobile_card);
        multimedia_card = findViewById(R.id.multimedia_card);
        plumbing_card = findViewById(R.id.plumbing_card);
        fridge_card = findViewById(R.id.fridge_card);
        computer_card = findViewById(R.id.computer_card);
        wm_card = findViewById(R.id.wm_card);
  */
        toolbar = findViewById(R.id.toolbar);
        navigationView1 = findViewById(R.id.dash_navigation_view);

        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_open, R.string.navigation_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView1.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {

                    case R.id.ac_technician_menu:
//                        fragment(new ac_technician_fragment());
//                        drawerLayout.closeDrawer(GravityCompat.START);
//                        Toast.makeText(dashboard.this, "Air Conditioning Technicians", Toast.LENGTH_SHORT).show();
//                        break;
                }
                return true;
            }
        });

    /*    //AC service intent
        ac_card.setOnClickListener(view -> {
            Intent ac_intent = new Intent(dashboard.this, ac_services.class);
            startActivity(ac_intent);
            Toast.makeText(dashboard.this, "Clicked on AC Services", Toast.LENGTH_SHORT).show();
        });
        //Refrigerator service intent
        fridge_card.setOnClickListener(view -> {
            Intent fridge_intent = new Intent(dashboard.this, refrigerator_services.class);
            startActivity(fridge_intent);
            Toast.makeText(dashboard.this, "Clicked on Refrigerator Services", Toast.LENGTH_SHORT).show();
        });
        //Laptop service intent
        laptop_card.setOnClickListener(view -> {
            Intent lap_intent = new Intent(dashboard.this, laptop_services.class);
            startActivity(lap_intent);
            Toast.makeText(dashboard.this, "Clicked on Laptop Services", Toast.LENGTH_SHORT).show();
        });
        //Computer service intent
        computer_card.setOnClickListener(view -> {
            Intent comp_intent = new Intent(dashboard.this, computer_services.class);
            startActivity(comp_intent);
            Toast.makeText(dashboard.this, "Clicked on Computer Services", Toast.LENGTH_SHORT).show();
        });
        //Mobile service intent
        mobile_card.setOnClickListener(view -> {
            Intent mobile_intent = new Intent(dashboard.this, mobile_services.class);
            startActivity(mobile_intent);
            Toast.makeText(dashboard.this, "Clicked on Mobile Services", Toast.LENGTH_SHORT).show();
        });
        //Multimedia service intent
        multimedia_card.setOnClickListener(view -> {
            Intent multimedia_intent = new Intent(dashboard.this, multimedia_services.class);
            startActivity(multimedia_intent);
            Toast.makeText(dashboard.this, "Clicked on Multimedia Services", Toast.LENGTH_SHORT).show();
        });
        //Plumbing service intent
        plumbing_card.setOnClickListener(view -> {
            Intent plumb_intent = new Intent(dashboard.this, plumbing_services.class);
            startActivity(plumb_intent);
            Toast.makeText(dashboard.this, "Clicked on Plumbing Services", Toast.LENGTH_SHORT).show();
        });
        //WM service intent
        wm_card.setOnClickListener(view -> {
            Intent wm_intent = new Intent(dashboard.this, wm_services.class);
            startActivity(wm_intent);
            Toast.makeText(dashboard.this, "Clicked on WM Services", Toast.LENGTH_SHORT).show();
        });

//        New Work
     */
//
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.dashboard_frame_layout, new dashboard_fragment());
        fragmentTransaction.commit();
    }
}
