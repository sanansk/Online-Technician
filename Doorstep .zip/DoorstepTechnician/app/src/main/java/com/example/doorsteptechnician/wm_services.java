package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class wm_services extends AppCompatActivity {
    ImageView wm_dashboard_img;
    CardView wm_control_card,wm_drum_card,wm_pump_card,wm_belt_card,wm_drain_card,wm_inlet_valve_card;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wm_services);

        wm_dashboard_img= findViewById(R.id.wm_dashboard_img);
        wm_control_card= findViewById(R.id.wm_control_card);
        wm_drum_card= findViewById(R.id.wm_drum_card);
        wm_pump_card= findViewById(R.id.wm_pump_card);
        wm_belt_card= findViewById(R.id.wm_belt_card);
        wm_drain_card= findViewById(R.id.wm_drain_card);
        wm_inlet_valve_card= findViewById(R.id.wm_inlet_valve_card);

        //WM Control Board Repair Intent
        wm_control_card.setOnClickListener(view -> {
            Intent wm_control= new Intent(wm_services.this,wm_technician.class);
            startActivity(wm_control);
            Toast.makeText(wm_services.this, "Clicked on WM Control Board Repair", Toast.LENGTH_SHORT).show();
        });
        //WM Drum Repair Intent
        wm_drum_card.setOnClickListener(view -> {
            Intent wm_drum= new Intent(wm_services.this,wm_technician.class);
            startActivity(wm_drum);
            Toast.makeText(wm_services.this, "Clicked on WM Drum Repair", Toast.LENGTH_SHORT).show();
        });
        //WM Pump Repair Intent
        wm_pump_card.setOnClickListener(view -> {
            Intent wm_pump= new Intent(wm_services.this,wm_technician.class);
            startActivity(wm_pump);
            Toast.makeText(wm_services.this, "Clicked on WM Pump Repair", Toast.LENGTH_SHORT).show();
        });
        //WM Belt Repair Intent
        wm_belt_card.setOnClickListener(view -> {
            Intent wm_belt= new Intent(wm_services.this,wm_technician.class);
            startActivity(wm_belt);
            Toast.makeText(wm_services.this, "Clicked on WM Belt Repair", Toast.LENGTH_SHORT).show();
        });
        //WM Drain Hose Repair Intent
        wm_drain_card.setOnClickListener(view -> {
            Intent wm_drain= new Intent(wm_services.this,wm_technician.class);
            startActivity(wm_drain);
            Toast.makeText(wm_services.this, "Clicked on WM Drain Hose Repair", Toast.LENGTH_SHORT).show();
        });
        //WM Inlet Valve Repair Intent
        wm_inlet_valve_card.setOnClickListener(view -> {
            Intent wm_inlet= new Intent(wm_services.this,wm_technician.class);
            startActivity(wm_inlet);
            Toast.makeText(wm_services.this, "Clicked on WM Inlet Valve Repair", Toast.LENGTH_SHORT).show();
        });

    }
}