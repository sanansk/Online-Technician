package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class plumbing_technician extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plumbing_technician);
    }
}