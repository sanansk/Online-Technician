package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class plumbing_services extends AppCompatActivity {
    ImageView plumber_dashboard_img;
    CardView plumb_installation_card,plumb_repair_card,plumb_sewerline_card,plumb_waterheater_card,plumb_fixtures_card,plumb_gasline_card;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plumbing_services);

        plumber_dashboard_img= findViewById(R.id.plumber_dashboard_img);
        plumb_installation_card= findViewById(R.id.plumb_installation_card);
        plumb_repair_card= findViewById(R.id.plumb_repair_card);
        plumb_sewerline_card= findViewById(R.id.plumb_sewerline_card);
        plumb_waterheater_card= findViewById(R.id.plumb_waterheater_card);
        plumb_fixtures_card= findViewById(R.id.plumb_fixtures_card);
        plumb_gasline_card= findViewById(R.id.plumb_gasline_card);

        // Plumbing New System Installation Intent
        plumb_installation_card.setOnClickListener(view -> {
            Intent plumb_install= new Intent(plumbing_services.this, plumbing_technician.class);
            startActivity(plumb_install);
            Toast.makeText(plumbing_services.this, "Clicked on Plumbing New System Installation", Toast.LENGTH_SHORT).show();
        });
        // Plumbing Old System Repair Intent
        plumb_repair_card.setOnClickListener(view -> {
            Intent plumb_repair= new Intent(plumbing_services.this, plumbing_technician.class);
            startActivity(plumb_repair);
            Toast.makeText(plumbing_services.this, "Clicked on Plumbing Old System Repair", Toast.LENGTH_SHORT).show();
        });
        // Plumbing Sewer Line repair Intent
        plumb_sewerline_card.setOnClickListener(view -> {
            Intent plumb_sewerline= new Intent(plumbing_services.this, plumbing_technician.class);
            startActivity(plumb_sewerline);
            Toast.makeText(plumbing_services.this, "Clicked on Plumbing Sewer-Line Install/Repair", Toast.LENGTH_SHORT).show();
        });
        // Plumbing Water Heater install Intent
        plumb_waterheater_card.setOnClickListener(view -> {
            Intent plumb_waterheater= new Intent(plumbing_services.this, plumbing_technician.class);
            startActivity(plumb_waterheater);
            Toast.makeText(plumbing_services.this, "Clicked on Plumbing Water-heater Install/Repair", Toast.LENGTH_SHORT).show();
        });
        // Plumbing Fixtures Installation Intent
        plumb_fixtures_card.setOnClickListener(view -> {
            Intent plumb_fixtures= new Intent(plumbing_services.this, plumbing_technician.class);
            startActivity(plumb_fixtures);
            Toast.makeText(plumbing_services.this, "Clicked on Plumbing Fixtures Install/Repair", Toast.LENGTH_SHORT).show();
        });
        // Plumbing Gas-line Installation Intent
        plumb_gasline_card.setOnClickListener(view -> {
            Intent plumb_gasline= new Intent(plumbing_services.this, plumbing_technician.class);
            startActivity(plumb_gasline);
            Toast.makeText(plumbing_services.this, "Clicked on Gas-Line Install/Repair", Toast.LENGTH_SHORT).show();
        });
    }
}