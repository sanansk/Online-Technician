package com.example.doorsteptechnician;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class refrigerator_services extends AppCompatActivity {
    ImageView fridge_dashboard_img;
    CardView fridge_repair_card,fridge_maintain_card,fridge_compressor_card,fridge_wiring_card,fridge_restoration_card,fridge_parts_replace_card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refrigerator_services);

        fridge_dashboard_img= findViewById(R.id.fridge_dashboard_img);
        fridge_repair_card= findViewById(R.id.fridge_repair_card);
        fridge_maintain_card= findViewById(R.id.fridge_maintain_card);
        fridge_compressor_card= findViewById(R.id.fridge_compressor_card);
        fridge_wiring_card= findViewById(R.id.fridge_wiring_card);
        fridge_restoration_card= findViewById(R.id.fridge_restoration_card);
        fridge_parts_replace_card= findViewById(R.id.fridge_parts_replace_card);

        // Fridge Repair Intent
        fridge_repair_card.setOnClickListener(view -> {
            Intent fridge_repair= new Intent(refrigerator_services.this, refrigerator_technician.class);
            startActivity(fridge_repair);
            Toast.makeText(refrigerator_services.this, "Clicked on Fridge Repair", Toast.LENGTH_SHORT).show();
        });
        // Fridge Maintenance Intent
        fridge_maintain_card.setOnClickListener(view -> {
            Intent fridge_maintain= new Intent(refrigerator_services.this, refrigerator_technician.class);
            startActivity(fridge_maintain);
            Toast.makeText(refrigerator_services.this, "Clicked on Fridge Maintenance", Toast.LENGTH_SHORT).show();
        });
        // Fridge Compressor Check Intent
        fridge_compressor_card.setOnClickListener(view -> {
            Intent fridge_Compressor= new Intent(refrigerator_services.this, refrigerator_technician.class);
            startActivity(fridge_Compressor);
            Toast.makeText(refrigerator_services.this, "Clicked on Fridge Compressor Check", Toast.LENGTH_SHORT).show();
        });
        // Fridge Wiring Intent
        fridge_wiring_card.setOnClickListener(view -> {
            Intent fridge_wiring= new Intent(refrigerator_services.this, refrigerator_technician.class);
            startActivity(fridge_wiring);
            Toast.makeText(refrigerator_services.this, "Clicked on Fridge Wiring", Toast.LENGTH_SHORT).show();
        });
        // Fridge Restoration Intent
        fridge_restoration_card.setOnClickListener(view -> {
            Intent fridge_restoration= new Intent(refrigerator_services.this, refrigerator_technician.class);
            startActivity(fridge_restoration);
            Toast.makeText(refrigerator_services.this, "Clicked on Fridge Restoration", Toast.LENGTH_SHORT).show();
        });
        // Fridge Parts_replace Intent
        fridge_parts_replace_card.setOnClickListener(view -> {
            Intent fridge_parts= new Intent(refrigerator_services.this, refrigerator_technician.class);
            startActivity(fridge_parts);
            Toast.makeText(refrigerator_services.this, "Clicked on Fridge Parts_replace", Toast.LENGTH_SHORT).show();
        });
    }
}